# DarkFb Premium
# No Lisensi

<ul>
Untuk Penginstallan
<ul>
<li><code>apt update && apt upgrade</code></li>
<li><code>pkg install git python2</code></li>
<li><code>pip2 install mechanize requests</code></li>
<li><code>git clone https://github.com/B4N954N2-ID/DarkPremium</code></li>
<li><code>cd DarkPremium</code></li>
<li><code>python2 darkpremium.py</code></li>
</ul>
<br />
<br />
<img src="https://github.com/B4N954N2-ID/darkpremium/blob/master/Screenshot_20190928-121958.png" />
